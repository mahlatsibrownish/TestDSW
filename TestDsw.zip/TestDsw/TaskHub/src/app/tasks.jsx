import TaskScreen from "../Screens/TaskScreen";

export default function Tasks() {
  return <TaskScreen />;
}