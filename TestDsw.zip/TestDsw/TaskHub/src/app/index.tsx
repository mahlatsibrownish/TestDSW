import React, { useEffect, useState } from "react";
import {
  View,
  ActivityIndicator,
  StyleSheet,
} from "react-native";

import {
  onAuthStateChanged,
  User,
} from "firebase/auth";

import { auth } from "../Firebase/FirebaseConfig";

import LogInScreen from "../Screens/LogInScreen";
import TaskScreen from "../Screens/TaskScreen";

export default function Index() {
  const [user, setUser] = useState<User | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (firebaseUser) => {
        setUser(firebaseUser);
        setCheckingAuth(false);
      }
    );

    return unsubscribe;
  }, []);

  // Firebase is checking if someone is already logged in
  if (checkingAuth) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  // No logged-in user
  if (!user) {
    return <LogInScreen />;
  }

  // Logged-in user
  return <TaskScreen />;
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});