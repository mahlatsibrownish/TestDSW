import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from "react-native";

import { doc, getDoc } from "firebase/firestore";
import { signOut } from "firebase/auth";

import {
  auth,
  db,
} from "../Firebase/FirebaseConfig";

export default function ProfileScreen() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loggingOut, setLoggingOut] = useState(false);
  const [error, setError] = useState("");

  // ==========================================
  // LOAD CURRENT USER PROFILE
  // ==========================================

  useEffect(() => {
    const loadProfile = async () => {
      try {
        setLoading(true);
        setError("");

        // Get currently authenticated Firebase user
        const currentUser = auth.currentUser;

        if (!currentUser) {
          setError("No authenticated user found.");
          return;
        }

        // IMPORTANT:
        // The document ID is the Firebase Authentication UID.
        const userDocument = doc(
          db,
          "users",
          currentUser.uid
        );

        const userSnapshot = await getDoc(userDocument);

        if (userSnapshot.exists()) {
          setProfile({
            id: userSnapshot.id,
            ...userSnapshot.data(),
          });
        } else {
          setError("User profile could not be found.");
        }
      } catch (profileError) {
        console.log(
          "Profile error:",
          profileError
        );

        setError(
          "Unable to load your profile."
        );
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, []);

  // ==========================================
  // LOGOUT
  // ==========================================

  const handleLogout = async () => {
    try {
      setLoggingOut(true);

      // Remove private profile information
      // from the screen before signing out.
      setProfile(null);

      await signOut(auth);

      /*
        Do NOT manually navigate to Login here.

        Your root onAuthStateChanged listener
        should detect that the user is now null
        and automatically show LogInScreen.
      */
    } catch (logoutError) {
      console.log(
        "Logout error:",
        logoutError
      );

      Alert.alert(
        "Logout Failed",
        "Unable to sign out. Please try again."
      );
    } finally {
      setLoggingOut(false);
    }
  };

  // ==========================================
  // LOADING
  // ==========================================

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator
          size="large"
          color="#2563eb"
        />

        <Text style={styles.loadingText}>
          Loading profile...
        </Text>
      </View>
    );
  }

  // ==========================================
  // ERROR
  // ==========================================

  if (error) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorTitle}>
          Profile Error
        </Text>

        <Text style={styles.errorText}>
          {error}
        </Text>
      </View>
    );
  }

  // ==========================================
  // PROFILE SCREEN
  // ==========================================

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>
        Student Profile
      </Text>

      <Text style={styles.subtitle}>
        Your account information
      </Text>

      <View style={styles.profileCard}>

        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {profile?.studentName
              ?.charAt(0)
              ?.toUpperCase() || "S"}
          </Text>
        </View>

        <Text style={styles.studentName}>
          {profile?.studentName}
        </Text>

        <View style={styles.informationContainer}>
          <Text style={styles.label}>
            Student Name
          </Text>

          <Text style={styles.value}>
            {profile?.studentName}
          </Text>
        </View>

        <View style={styles.informationContainer}>
          <Text style={styles.label}>
            Email Address
          </Text>

          <Text style={styles.value}>
            {profile?.email}
          </Text>
        </View>

      </View>

      <TouchableOpacity
        style={[
          styles.logoutButton,
          loggingOut && styles.disabledButton,
        ]}
        onPress={handleLogout}
        disabled={loggingOut}
      >
        {loggingOut ? (
          <ActivityIndicator color="white" />
        ) : (
          <Text style={styles.logoutText}>
            LOG OUT
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

// ==========================================
// STYLES
// ==========================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f4f6f9",
    padding: 20,
    paddingTop: 60,
  },

  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f4f6f9",
    padding: 20,
  },

  heading: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 5,
  },

  subtitle: {
    textAlign: "center",
    color: "#666",
    marginBottom: 30,
  },

  profileCard: {
    backgroundColor: "white",
    borderRadius: 12,
    padding: 25,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },

  avatar: {
    width: 75,
    height: 75,
    borderRadius: 38,
    backgroundColor: "#2563eb",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    marginBottom: 15,
  },

  avatarText: {
    color: "white",
    fontSize: 32,
    fontWeight: "bold",
  },

  studentName: {
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 25,
  },

  informationContainer: {
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    paddingVertical: 15,
  },

  label: {
    fontSize: 13,
    color: "#666",
    marginBottom: 5,
  },

  value: {
    fontSize: 17,
    fontWeight: "500",
  },

  logoutButton: {
    backgroundColor: "#dc2626",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },

  logoutText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 15,
  },

  disabledButton: {
    opacity: 0.6,
  },

  loadingText: {
    marginTop: 12,
    color: "#555",
  },

  errorTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#dc2626",
    marginBottom: 8,
  },

  errorText: {
    color: "#666",
    textAlign: "center",
  },
});