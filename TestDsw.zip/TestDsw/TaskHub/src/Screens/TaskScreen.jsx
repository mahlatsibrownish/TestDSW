import React, { useEffect, useState } from "react";

import {
  View,Text,TextInput,TouchableOpacity,FlatList,StyleSheet,ActivityIndicator,Alert,SafeAreaView ,
} from "react-native";
import {collection,onSnapshot,addDoc,serverTimestamp,doc,updateDoc,deleteDoc,} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth, db } from "../Firebase/FirebaseConfig";
import { router } from "expo-router";



export default function TaskScreen() {
  // =========================================
  // STATE
  // =========================================

  const [tasks, setTasks] = useState([]);

  const [title, setTitle] = useState("");
  const [moduleCode, setModuleCode] = useState("");
  const [priority, setPriority] = useState("Low");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // =========================================
  // REAL-TIME FIRESTORE LISTENER
  // =========================================

  useEffect(() => {
    const tasksCollection = collection(db, "tasks");

    const unsubscribe = onSnapshot(
      tasksCollection,

      (snapshot) => {
        const taskList = snapshot.docs.map((document) => {
          return {
            id: document.id,
            ...document.data(),
          };
        });

        setTasks(taskList);
        setLoading(false);
        setError("");
      },

      (listenerError) => {
        console.log(
          "Firestore listener error:",
          listenerError
        );

        setError(
          "Unable to load tasks from Firestore."
        );

        setLoading(false);
      }
    );

    // Stop listening when component unmounts
    return () => {
      unsubscribe();
    };
  }, []);

  // =========================================
  // ADD TASK
  // =========================================

  const addTask = async () => {
    if (!title.trim()) {
      Alert.alert(
        "Validation Error",
        "Please enter a task title."
      );
      return;
    }

    if (!moduleCode.trim()) {
      Alert.alert(
        "Validation Error",
        "Please enter a module code."
      );
      return;
    }

    try {
      setSaving(true);
      setError("");

      await addDoc(collection(db, "tasks"), {
        title: title.trim(),

        moduleCode: moduleCode
          .trim()
          .toUpperCase(),

        priority: priority,

        completed: false,

        createdAt: serverTimestamp(),
      });

      // Clear only AFTER Firestore succeeds
      setTitle("");
      setModuleCode("");
      setPriority("Low");
    } catch (addError) {
      console.log(
        "Add task error:",
        addError
      );

      setError(
        "The task could not be added."
      );

      Alert.alert(
        "Error",
        "Unable to add the task."
      );
    } finally {
      setSaving(false);
    }
  };

  // =========================================
  // COMPLETE / INCOMPLETE TASK
  // =========================================

  const toggleTask = async (task) => {
    try {
      setError("");

      const taskDocument = doc(
        db,
        "tasks",
        task.id
      );

      await updateDoc(taskDocument, {
        completed: !task.completed,
      });

      /*
        We do NOT manually change tasks here.

        onSnapshot() will receive the updated
        Firestore document and update the UI.
      */
    } catch (updateError) {
      console.log(
        "Update error:",
        updateError
      );

      setError(
        "The task could not be updated."
      );

      Alert.alert(
        "Error",
        "Unable to update this task."
      );
    }
  };

  // =========================================
  // DELETE TASK
  // =========================================

  const removeTask = (task) => {
    Alert.alert(
      "Delete Task",
      `Delete "${task.title}"?`,
      [
        {
          text: "Cancel",
          style: "cancel",
        },

        {
          text: "Delete",
          style: "destructive",

          onPress: async () => {
            try {
              setError("");

              const taskDocument = doc(
                db,
                "tasks",
                task.id
              );

              await deleteDoc(taskDocument);

              /*
                onSnapshot() automatically
                updates the FlatList.
              */
            } catch (deleteError) {
              console.log(
                "Delete error:",
                deleteError
              );

              setError(
                "The task could not be deleted."
              );

              Alert.alert(
                "Error",
                "Unable to delete this task."
              );
            }
          },
        },
      ]
    );
  };

  // =========================================
  // LOG OUT
  // =========================================

  const handleLogout = async () => {
    try {
      await signOut(auth);

      router.replace("/");
    } catch (logoutError) {
      console.log(
        "Logout error:",
        logoutError
      );

      Alert.alert(
        "Error",
        "Unable to log out."
      );
    }
  };

  // =========================================
  // DISPLAY EACH TASK
  // =========================================

  const renderTask = ({ item }) => {
    return (
      <View
        style={[
          styles.taskCard,

          item.completed &&
            styles.completedCard,
        ]}
      >
        <Text
          style={[
            styles.taskTitle,

            item.completed &&
              styles.completedTitle,
          ]}
        >
          {item.title}
        </Text>

        <Text style={styles.taskInformation}>
          Module: {item.moduleCode}
        </Text>

        <Text style={styles.taskInformation}>
          Priority: {item.priority}
        </Text>

        <Text
          style={[
            styles.status,

            item.completed
              ? styles.completeStatus
              : styles.incompleteStatus,
          ]}
        >
          {item.completed
            ? "✓ COMPLETED"
            : "INCOMPLETE"}
        </Text>

        <View style={styles.actionRow}>
          <TouchableOpacity
            style={styles.completeButton}
            onPress={() =>
              toggleTask(item)
            }
          >
            <Text style={styles.buttonText}>
              {item.completed
                ? "MARK INCOMPLETE"
                : "MARK COMPLETED"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() =>
              removeTask(item)
            }
          >
            <Text style={styles.buttonText}>
              DELETE
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // =========================================
  // SCREEN
  // =========================================

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.heading}>
            Academic Tasks
          </Text>

          <Text style={styles.headerSubtitle}>
            Manage your coursework
          </Text>
        </View>

        <TouchableOpacity
          onPress={handleLogout}
          style={styles.logoutButton}
        >
          <Text style={styles.logoutText}>
            LOGOUT
          </Text>
        </TouchableOpacity>
      </View>

      {/* ADD TASK */}

      <View style={styles.form}>
        <Text style={styles.sectionTitle}>
          Add New Task
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Task title"
          value={title}
          onChangeText={setTitle}
        />

        <TextInput
          style={styles.input}
          placeholder="Module code"
          value={moduleCode}
          onChangeText={setModuleCode}
          autoCapitalize="characters"
        />

        <Text style={styles.priorityLabel}>
          Priority
        </Text>

        <View style={styles.priorityRow}>
          {["Low", "Medium", "High"].map(
            (option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.priorityButton,

                  priority === option &&
                    styles.selectedPriority,
                ]}
                onPress={() =>
                  setPriority(option)
                }
              >
                <Text
                  style={[
                    styles.priorityText,

                    priority === option &&
                      styles.selectedPriorityText,
                  ]}
                >
                  {option}
                </Text>
              </TouchableOpacity>
            )
          )}
        </View>

        <TouchableOpacity
          style={[
            styles.addButton,

            saving &&
              styles.disabledButton,
          ]}
          onPress={addTask}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.buttonText}>
              ADD TASK
            </Text>
          )}
        </TouchableOpacity>
      </View>

      {/* ERROR */}

      {error ? (
        <Text style={styles.errorText}>
          {error}
        </Text>
      ) : null}

      <Text style={styles.sectionTitle}>
        Current Tasks
      </Text>

      {/* LOADING */}

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" />

          <Text style={styles.loadingText}>
            Loading tasks...
          </Text>
        </View>
      ) : (
        <FlatList
          data={tasks}

          // Stable Firestore document ID
          keyExtractor={(item) =>
            item.id
          }

          renderItem={renderTask}

          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyTitle}>
                No tasks available
              </Text>

              <Text style={styles.emptyText}>
                Add your first academic task above.
              </Text>
            </View>
          }

          contentContainerStyle={
            tasks.length === 0
              ? styles.emptyList
              : styles.taskList
          }

          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

//
// STYLES
// =

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f4f6f9",
    paddingHorizontal: 18,
    paddingTop: 15,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },

  heading: {
    fontSize: 26,
    fontWeight: "bold",
  },

  headerSubtitle: {
    color: "#666",
    marginTop: 3,
  },

  logoutButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "#dc2626",
  },

  logoutText: {
    color: "#dc2626",
    fontWeight: "bold",
  },

  form: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: "bold",
    marginBottom: 12,
  },

  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 7,
    padding: 12,
    marginBottom: 10,
    fontSize: 16,
    backgroundColor: "#fff",
  },

  priorityLabel: {
    fontWeight: "600",
    marginBottom: 8,
  },

  priorityRow: {
    flexDirection: "row",
    marginBottom: 15,
  },

  priorityButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#2563eb",
    borderRadius: 7,
    padding: 10,
    alignItems: "center",
    marginHorizontal: 3,
  },

  selectedPriority: {
    backgroundColor: "#2563eb",
  },

  priorityText: {
    color: "#2563eb",
    fontWeight: "600",
  },

  selectedPriorityText: {
    color: "white",
  },

  addButton: {
    backgroundColor: "#2563eb",
    padding: 14,
    borderRadius: 7,
    alignItems: "center",
  },

  disabledButton: {
    opacity: 0.6,
  },

  buttonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 13,
  },

  errorText: {
    backgroundColor: "#fee2e2",
    color: "#b91c1c",
    padding: 10,
    borderRadius: 6,
    marginBottom: 12,
  },

  taskList: {
    paddingBottom: 30,
  },

  taskCard: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 15,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#ddd",
  },

  completedCard: {
    backgroundColor: "#e8f5e9",
    opacity: 0.75,
  },

  taskTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 7,
  },

  completedTitle: {
    textDecorationLine: "line-through",
  },

  taskInformation: {
    fontSize: 14,
    marginBottom: 4,
    color: "#444",
  },

  status: {
    marginTop: 7,
    fontWeight: "bold",
  },

  completeStatus: {
    color: "#15803d",
  },

  incompleteStatus: {
    color: "#dc2626",
  },

  actionRow: {
    flexDirection: "row",
    marginTop: 13,
  },

  completeButton: {
    flex: 1,
    backgroundColor: "#16a34a",
    padding: 11,
    borderRadius: 6,
    alignItems: "center",
    marginRight: 7,
  },

  deleteButton: {
    backgroundColor: "#dc2626",
    padding: 11,
    borderRadius: 6,
    alignItems: "center",
  },

  loadingContainer: {
    padding: 40,
    alignItems: "center",
  },

  loadingText: {
    marginTop: 10,
    color: "#555",
  },

  emptyList: {
    flexGrow: 1,
  },

  emptyContainer: {
    alignItems: "center",
    padding: 40,
  },

  emptyTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },

  emptyText: {
    color: "#666",
    textAlign: "center",
  },
});