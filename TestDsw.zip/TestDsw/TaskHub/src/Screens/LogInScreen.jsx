import React, { useState } from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from "react-native";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";

import {
  doc,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";

import {
  auth,
  db,
} from "../Firebase/FirebaseConfig";

export default function LogInScreen() {
  // true = Login screen
  // false = Registration screen
  const [isLogin, setIsLogin] = useState(true);

  const [studentName, setStudentName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);

  // ==========================================
  // LOGIN
  // ==========================================

  const handleLogin = async () => {
    // Validate fields before Firebase
    if (!email.trim() || !password.trim()) {
      Alert.alert(
        "Missing Fields",
        "Please enter your email and password."
      );
      return;
    }

    try {
      setLoading(true);

      await signInWithEmailAndPassword(
        auth,
        email.trim(),
        password
      );

      /*
        No manual navigation is needed here.

        onAuthStateChanged in index.tsx should
        detect the signed-in user and display
        the protected area.
      */

    } catch (error) {
      console.log("Login error:", error.code);

      let message = "Unable to sign in.";

      if (error.code === "auth/invalid-email") {
        message = "Please enter a valid email address.";
      } else if (error.code === "auth/invalid-credential") {
        message = "Incorrect email or password.";
      } else if (error.code === "auth/too-many-requests") {
        message =
          "Too many login attempts. Please try again later.";
      } else if (error.code === "auth/network-request-failed") {
        message =
          "Network error. Please check your internet connection.";
      }

      Alert.alert("Login Failed", message);

    } finally {
      setLoading(false);
    }
  };

  // ==========================================
  // REGISTER
  // ==========================================

  const handleRegister = async () => {
    // Registration additionally requires name
    if (
      !studentName.trim() ||
      !email.trim() ||
      !password.trim()
    ) {
      Alert.alert(
        "Missing Fields",
        "Please enter your student name, email and password."
      );
      return;
    }

    try {
      setLoading(true);

      // STEP 1:
      // Create Firebase Authentication account
      const result =
        await createUserWithEmailAndPassword(
          auth,
          email.trim(),
          password
        );

      const user = result.user;

      // STEP 2:
      // Create this user's Firestore profile.
      //
      // IMPORTANT:
      // Firebase UID is the document ID.
      await setDoc(
        doc(db, "users", user.uid),
        {
          studentName: studentName.trim(),

          email: user.email,

          createdAt: serverTimestamp(),
        }
      );

      /*
        Firebase automatically signs the user
        in after successful registration.

        onAuthStateChanged in index.tsx will
        detect this.
      */

    } catch (error) {
      console.log(
        "Registration error:",
        error.code
      );

      let message =
        "Unable to create your account.";

      if (
        error.code ===
        "auth/email-already-in-use"
      ) {
        message =
          "An account already exists with this email.";
      } else if (
        error.code === "auth/invalid-email"
      ) {
        message =
          "Please enter a valid email address.";
      } else if (
        error.code === "auth/weak-password"
      ) {
        message =
          "Your password is too weak.";
      } else if (
        error.code ===
        "auth/network-request-failed"
      ) {
        message =
          "Network error. Please check your internet connection.";
      }

      Alert.alert(
        "Registration Failed",
        message
      );

    } finally {
      setLoading(false);
    }
  };

  // ==========================================
  // SCREEN
  // ==========================================

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <Text style={styles.title}>
          Student Portal
        </Text>

        <Text style={styles.subtitle}>
          {isLogin
            ? "Sign in to your account"
            : "Create your student account"}
        </Text>

        {/* STUDENT NAME
            Only displayed when registering
        */}

        {!isLogin && (
          <>
            <Text style={styles.label}>
              Student Name
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Enter student name"
              value={studentName}
              onChangeText={setStudentName}
              editable={!loading}
            />
          </>
        )}

        {/* EMAIL */}

        <Text style={styles.label}>
          Email
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Enter email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          editable={!loading}
        />

        {/* PASSWORD */}

        <Text style={styles.label}>
          Password
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Enter password"
          value={password}
          onChangeText={setPassword}

          // Secure password entry
          secureTextEntry

          editable={!loading}
        />

        {/* LOGIN / REGISTER BUTTON */}

        <TouchableOpacity
          style={[
            styles.submitButton,
            loading && styles.disabledButton,
          ]}

          onPress={
            isLogin
              ? handleLogin
              : handleRegister
          }

          // Prevent repeated Firebase requests
          disabled={loading}
        >

          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.submitText}>
              {isLogin
                ? "LOGIN"
                : "REGISTER"}
            </Text>
          )}

        </TouchableOpacity>

        {/* SWITCH LOGIN / REGISTER */}

        <TouchableOpacity
          disabled={loading}
          onPress={() => {
            setIsLogin(!isLogin);

            // Clear password when switching
            setPassword("");
          }}
        >
          <Text style={styles.switchText}>
            {isLogin
              ? "Don't have an account? Register"
              : "Already have an account? Login"}
          </Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}


// ==========================================
// STYLES
// ==========================================

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#f4f6f9",
    padding: 20,
  },

  card: {
    backgroundColor: "white",
    padding: 25,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 5,
  },

  subtitle: {
    textAlign: "center",
    color: "#666",
    marginBottom: 25,
  },

  label: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 6,
  },

  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    padding: 13,
    marginBottom: 16,
    fontSize: 16,
    backgroundColor: "#fff",
  },

  submitButton: {
    backgroundColor: "#2563eb",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 5,
  },

  disabledButton: {
    opacity: 0.6,
  },

  submitText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },

  switchText: {
    color: "#2563eb",
    textAlign: "center",
    marginTop: 20,
    fontWeight: "600",
  },

});