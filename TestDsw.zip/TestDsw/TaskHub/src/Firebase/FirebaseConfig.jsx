// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAetpZ856hoL23NXpuoG8VgwyyHDbcMiSE",
  authDomain: "ttasks-bb00d.firebaseapp.com",
  projectId: "ttasks-bb00d",
  storageBucket: "ttasks-bb00d.firebasestorage.app",
  messagingSenderId: "526724117155",
  appId: "1:526724117155:web:19bf45cabe637b47c10516",
  measurementId: "G-6DZ1GN4YB0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };